
package sokoban;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;


public class PlaySound {
    public Clip load(String file) {
    Clip clip = null;
    try{
        AudioInputStream audioIn = AudioSystem.getAudioInputStream(getClass().getResource(file));
        clip=AudioSystem.getClip();
        clip.open(audioIn);
    }catch(Exception ex){
        ex.printStackTrace();
    }
    return clip;
    }
    
    public void play(Clip clip){
        stop(clip);
        clip.start();
    }
    public void stop(Clip clip){
        if(clip.isRunning()){
            clip.stop();
        }
    }
}
