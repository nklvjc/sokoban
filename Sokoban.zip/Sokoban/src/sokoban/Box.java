
package sokoban;

import java.awt.Image;
import java.net.URL;
import javax.swing.ImageIcon;

public class Box extends Movement{
    public Box(int tileX, int tileY){
        super(tileX, tileY);
            URL img = getClass().getResource("/images/baggage3cc.png");
            ImageIcon imgIcon = new ImageIcon(img);
            Image image = imgIcon.getImage();
            this.setPlayer(image);
    }
    public void move(int dx, int dy){
        this.setTileX(this.getTileX()+dx);
        this.setTileY(this.getTileY()+dy);
    }
}
