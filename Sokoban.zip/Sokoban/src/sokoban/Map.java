
package sokoban;

import java.awt.Image;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Map{
    private Scanner m;
    private String Map[] = new String[10];
    private Image grass,wall,box,finish,player;
    
    public Map(){
        Grass g = new Grass(0,0);
        grass = g.getPlayer();
        Wall w = new Wall(0,0);
        wall = w.getPlayer();
        Box b = new Box(0,0);
        box = b.getPlayer();
        Finish f = new Finish(0,0);
        finish = f.getPlayer();
        Player p = new Player(0,0);
        player = p.getPlayer();
        openFile();
        readFile();
        closeFile();
    }

    public Scanner getM() {
        return m;
    }

    public void setM(Scanner m) {
        this.m = m;
    }

    public String[] getMap() {
        return Map;
    }

    public void setMap(String[] Map) {
        this.Map = Map;
    }

    public Image getGrass() {
        return grass;
    }

    public void setGrass(Image grass) {
        this.grass = grass;
    }

    public Image getWall() {
        return wall;
    }

    public void setWall(Image wall) {
        this.wall = wall;
    }

    public Image getBox() {
        return box;
    }

    public void setBox(Image box) {
        this.box = box;
    }

    public Image getFinish() {
        return finish;
    }

    public void setFinish(Image finish) {
        this.finish = finish;
    }

    public Image getPlayer() {
        return player;
    }

    public void setPlayer(Image player) {
        this.player = player;
    }
    
    public String getMap(int x, int y){
        String index = Map[y].substring(x, x+1);
        return index;
    }
    
    public void openFile(){
        URL url = getClass().getResource("/levels/level1.txt");
        try {
            m = new Scanner(new BufferedInputStream(url.openStream()));
        } catch (IOException ex) {
            Logger.getLogger(Map.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void readFile(){
        while(m.hasNext()){
            for (int i = 0; i < 10; i++) {
                Map[i] = m.next();
                
            }
        }
    }
    public void closeFile(){
        m.close();
    }
}
