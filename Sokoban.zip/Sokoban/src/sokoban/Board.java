
package sokoban;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.sound.sampled.Clip;
import javax.swing.JPanel;
import sun.java2d.pipe.RenderingEngine;

public class Board extends JPanel{
    PlaySound sound = new PlaySound();
    private ArrayList walls = new ArrayList();
    private ArrayList boxes = new ArrayList();
    private ArrayList fields = new ArrayList();
    private ArrayList all = new ArrayList();
    private Map m;
    private Player p;
    private Wall w;
    private Box b, bPrevious;
    private Grass g;
    private Finish f;
    private int turn = 0;
    private int moves = 0;
    private int undoMoves = 0;
    private boolean win = false;
    private boolean theEnd = false;
    private boolean boxMoved;
    private String message = "Winner";
    private Font font1;
    private Font font2;
    private int keycode2;
    
    public Board(){
        addKeyListener(new Al());
        setFocusable(true);
        m = new Map();
        playGround();
    }
    public void playGround(){
        for (int y = 0; y < 10; y++) {
            for (int x = 0; x < 14; x++) {
                if(m.getMap(x, y).equals("w")){
                    w=new Wall(x,y);
                    walls.add(w);
                }
                else if(m.getMap(x, y).equals("t")){
                    f=new Finish(x,y);
                    fields.add(f);
                }
                else if(m.getMap(x, y).equals("b")){
                    b=new Box(x,y);
                    boxes.add(b); 
                }
                else if(m.getMap(x, y).equals("s")){
                    p=new Player(x,y);
                }
            }
        }
    }
    
    public void paintComponent(Graphics gr) {
        super.paintComponent(gr);
        Graphics2D g2d = (Graphics2D)gr;
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_SPEED);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        
            all.addAll(walls);
            all.addAll(fields);
            all.addAll(boxes);
            all.add(p);
            int w = (this.getWidth())/14;
            int h = (this.getHeight())/10;
            for (int y = 0; y < 10; y++) {
                for (int x = 0; x < 14; x++) {
                    g2d.drawImage(m.getGrass(), x*w, y*h, w, h, null);
                }
            }
                
            for (int i = 0; i < all.size(); i++) {
                Movement m = (Movement) all.get(i);
                if((m instanceof Player)||(m instanceof Box)){
                    g2d.drawImage(m.getPlayer(), m.getTileX() * w, m.getTileY() * h,w,h, null);
                }else if((m instanceof Finish)||(m instanceof Wall)){
                    g2d.drawImage(m.getPlayer(), m.getTileX() * w, m.getTileY() * h,w,h, null);
                }
            }
            
            font1 = new Font("Serif", Font.BOLD, w/2);
            g2d.setColor(Color.WHITE);
            font2 = new Font("Serif", Font.BOLD, w);
            g2d.setFont(font1);
            g2d.drawString("Moves: "+moves, w/2, h/2);
            g2d.drawString("Undo: "+undoMoves+"/3", w*4, h/2);
        
        if(theEnd){
            g2d.setFont(font2);
            g2d.drawString("Game Over!", (p.getTileX()-1)*w, (p.getTileY()+2)*h);
        }
            
        if(win){
            g2d.setFont(font2);
            g2d.drawString(message, (p.getTileX()-1)*w, (p.getTileY()+2)*h);
            
        }
    }
    
    public void paint(Graphics g) {
        super.paint(g);
        paintComponent(g);
    }

    public class Al extends KeyAdapter{
        @Override
        public void keyPressed(KeyEvent e){
            int keycode = e.getKeyCode();
            if(win || theEnd){
                return;
            }
            
            if(keycode == KeyEvent.VK_UP){
                turn=1;
                if (wallCollision(p,turn)){
                    return;
                }
                if(boxCollision(turn)){
                    return;
                }
                p.move(0, -1);
                moves++;
                sound.play(sound.load("/music/move.wav"));
            }else if(keycode == KeyEvent.VK_DOWN){
                turn=2;
                if (wallCollision(p,turn)){
                    return;
                }
                if (boxCollision(turn)){
                    return;
                }
                p.move(0, 1);
                moves++;
                sound.play(sound.load("/music/move.wav"));
            }else if(keycode == KeyEvent.VK_LEFT){
                turn=3;
                if (wallCollision(p,turn)){
                    return;
                }
                if (boxCollision(turn)){
                    return;
                }
                p.move(-1, 0);
                moves++;
                sound.play(sound.load("/music/move.wav"));
            }else if(keycode == KeyEvent.VK_RIGHT){
                turn=4;
                if (wallCollision(p,turn)){
                    return;
                }
                if (boxCollision(turn)){
                    return;
                }
                p.move(1, 0);
                moves++;
                sound.play(sound.load("/music/move.wav"));
            }else if((keycode == KeyEvent.VK_U)&&(keycode != keycode2)){ 
                        if(turn==1){
                            if(wallCollision(p, turn+1)){
                                return;
                            }
                            if(boxCollision(5)){
                                return;
                            }
                            p.move(0, 1);
                            undoMoves++;
                            isGameFailed();
                        }else if(turn==2){
                            if(wallCollision(p, turn-1)){
                                return;
                            }
                            if(boxCollision(6)){
                                return;
                            }
                            p.move(0, -1);
                            undoMoves++;
                            isGameFailed();
                        }else if(turn==3){
                            if(wallCollision(p, turn+1)){
                                return;
                            }
                            if(boxCollision(7)){
                                return;
                            }
                            p.move(1, 0);
                            undoMoves++;
                            isGameFailed();
                        }else if(turn==4){
                            if(wallCollision(p, turn-1)){
                                return;
                            }
                            if(boxCollision(8)){
                                return;
                            }
                            p.move(-1, 0);
                            undoMoves++;
                            isGameFailed();
                        }
                    }
            keycode2 = keycode;
            repaint();
        }
        
        public boolean wallCollision(Player p, int turn){
            if(turn==1){
                for (int i = 0; i < walls.size(); i++) {
                    if (p.isTopCollision((Wall) walls.get(i))) {
                        return true;
                    }
                }
                return false;
            }
            if(turn==2){
                for (int i = 0; i < walls.size(); i++) {
                    if (p.isBottomCollision((Wall) walls.get(i))) {
                        return true;
                    }
                }
                return false;
            }
            if(turn==3){
                for (int i = 0; i < walls.size(); i++) {
                    if (p.isLeftCollision((Wall) walls.get(i))) {
                        return true;
                    }
                }
                return false;
            }
            if(turn==4){
                for (int i = 0; i < walls.size(); i++) {
                    if (p.isRightCollision((Wall) walls.get(i))) {
                        return true;
                    }
                }
                return false;
            }
            return false;
        }
        
        public boolean boxCollision(int turn){
            if(turn==1){
                for (int i = 0; i < boxes.size(); i++) {
                    Box b1=(Box)boxes.get(i);
                    if(p.isTopCollision(b1)){
                        for (int j = 0; j < boxes.size(); j++) {
                            Box b2=(Box)boxes.get(j);
                            if (!b1.equals(b2)) {
                                if (b1.isTopCollision(b2)) {
                                    return true;
                                }
                            }
                            Player p1=new Player(b1.getTileX(),b1.getTileY());
                            if(wallCollision(p1,turn))return true;
                        }
                        bPrevious = b1;
                        b1.move(0, -1);
                        isGameOver();
                    }
                }
                return false;
            }else if(turn==2){
               for (int i = 0; i < boxes.size(); i++) {
                    Box b1=(Box)boxes.get(i);
                    if(p.isBottomCollision(b1)){
                        for (int j = 0; j < boxes.size(); j++) {
                            Box b2=(Box)boxes.get(j);
                            if (!b1.equals(b2)) {
                                if (b1.isBottomCollision(b2)) {
                                    return true;
                                }
                            }
                            Player p1=new Player(b1.getTileX(),b1.getTileY());
                            if(wallCollision(p1,turn))return true;
                        }
                        bPrevious = b1;
                        b1.move(0, 1);
                        isGameOver();
                    }
                }
                return false;
            }else if(turn==3){
                for (int i = 0; i < boxes.size(); i++) {
                    Box b1=(Box)boxes.get(i);
                    if(p.isLeftCollision(b1)){
                        for (int j = 0; j < boxes.size(); j++) {
                            Box b2=(Box)boxes.get(j);
                            if (!b1.equals(b2)) {
                                if (b1.isLeftCollision(b2)) {
                                    return true;
                                }
                            }
                            Player p1=new Player(b1.getTileX(),b1.getTileY());
                            if(wallCollision(p1,turn))return true;
                        }
                        bPrevious = b1;
                        b1.move(-1, 0);
                        isGameOver();
                    }
                }
                return false;
            }else if(turn==4){
                for (int i = 0; i < boxes.size(); i++) {
                    Box b1=(Box)boxes.get(i);
                    if(p.isRightCollision(b1)){
                        for (int j = 0; j < boxes.size(); j++) {
                            Box b2=(Box)boxes.get(j);
                            if (!b1.equals(b2)) {
                                if (b1.isRightCollision(b2)) {
                                    return true;
                                }
                            }
                            Player p1=new Player(b1.getTileX(),b1.getTileY());
                            if(wallCollision(p1,turn))return true;
                        }
                        bPrevious = b1;
                        b1.move(1, 0);
                        isGameOver();
                    }
                }
            }else if(turn==5){
                for (int i = 0; i < boxes.size(); i++) {
                    Box b1=(Box)boxes.get(i);
                    if(p.isTopCollision(b1)){
                        if(!boxCollision(1))
                            b1.move(0, 1);
                            bPrevious.move(0, 1);
                            boxes.add(bPrevious);
                    }
                }
            }else if(turn==6){
                for (int i = 0; i < boxes.size(); i++) {
                    Box b1=(Box)boxes.get(i);
                    if(p.isBottomCollision(b1)){
                        if(!boxCollision(2))
                            b1.move(0, -1);
                            bPrevious.move(0, -1);
                            boxes.add(bPrevious);
                    }
                }
            }else if(turn==7){
                for (int i = 0; i < boxes.size(); i++) {
                    Box b1=(Box)boxes.get(i);
                    if(p.isLeftCollision(b1)){
                        if(!boxCollision(3))
                            b1.move(1, 0);
                            bPrevious.move(1, 0);
                            boxes.add(bPrevious);
                    }
                }
            }else if(turn==8){
                for (int i = 0; i < boxes.size(); i++) {
                    Box b1=(Box)boxes.get(i);
                    if(p.isRightCollision(b1)){
                        if(!boxCollision(4))
                            b1.move(-1, 0);
                            bPrevious.move(-1, 0);
                            boxes.add(bPrevious);
                    }
                }
            }
            return false;
        }
        public void isGameFailed(){
            if(undoMoves==3){
                theEnd = true;
            }
            if(theEnd){
                Clip clip = sound.load("/music/end.wav");
                if(clip.isRunning()){
                    clip.stop();
                }
                clip.start();
            }
            repaint();
        }
        public void isGameOver(){
            int counter = 0;
            
            for (int i = 0; i < boxes.size(); i++) {
                Box b=(Box) boxes.get(i);
                for (int j = 0; j < fields.size(); j++) {
                    Finish f=(Finish) fields.get(j);
                    if ((b.getTileX()==f.getTileX())&&(b.getTileY()==f.getTileY())) {
                        counter+=1;
                    }
                }
            }
            if (counter==boxes.size()) {
                win=true;
                Clip clip = sound.load("/music/win.wav");
                if(clip.isRunning()){
                    clip.stop();
                }
                clip.start();
            }
            repaint();
        }
    }
}

