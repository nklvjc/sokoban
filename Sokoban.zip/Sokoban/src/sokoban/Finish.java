
package sokoban;

import java.awt.Image;
import java.net.URL;
import javax.swing.ImageIcon;

public class Finish extends Movement{
    public Finish(int tileX, int tileY){
        super(tileX, tileY);
            URL img = getClass().getResource("/images/travnica4cc.png");
            ImageIcon imgIcon = new ImageIcon(img);
            Image image = imgIcon.getImage();
            this.setPlayer(image);
    }
}
