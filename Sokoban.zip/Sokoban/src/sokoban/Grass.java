
package sokoban;

import java.awt.Image;
import java.net.URL;
import javax.swing.ImageIcon;

public class Grass extends Movement{
    public Grass(int tileX, int tileY){
        super(tileX, tileY);
            URL img = getClass().getResource("/images/grass4cc.jpg");
            ImageIcon imgIcon = new ImageIcon(img);
            Image image = imgIcon.getImage();
            this.setPlayer(image);
    }
}

