
package sokoban;

import java.awt.Image;

public class Movement {
    private int tileX, tileY;
    private Image player;
    public Movement(int tileX, int tileY){
        this.tileX=tileX;
        this.tileY=tileY;
    }
    public int getTileX() {
        return tileX;
    }
    public void setTileX(int tileX) {
        this.tileX = tileX;
    }
    public int getTileY() {
        return tileY;
    }

    public void setTileY(int tileY) {
        this.tileY = tileY;
    }
    public Image getPlayer() {
        return player;
    }
    public void setPlayer(Image player) {
        this.player = player;
    }
    public boolean isTopCollision(Movement m){
        if((tileX == m.tileX)&&(tileY-1 == m.tileY))
            return true;
        else return false;
    }
    public boolean isBottomCollision(Movement m){
        if((tileX == m.tileX)&&(tileY+1 == m.tileY))
            return true;
        else return false;
    }
    public boolean isLeftCollision(Movement m){
        if((tileX-1 == m.tileX)&&(tileY == m.tileY))
            return true;
        else return false;
    }
    public boolean isRightCollision(Movement m){
        if((tileX+1 == m.tileX)&&(tileY == m.tileY))
            return true;
        else return false;
    }
}
