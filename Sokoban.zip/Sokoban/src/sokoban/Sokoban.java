
package sokoban;

import javax.swing.JFrame;

public class Sokoban {
    public Sokoban(){
        JFrame f = new JFrame();
        Board b = new Board();
        f.add(b);
        f.setTitle("Sokoban");
        f.setSize(464,359);
        f.setResizable(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null);
        System.setProperty("sun.java2d.opengl","True");
        f.setVisible(true);
    }
    public static void main(String[] args) {
       new Sokoban();
       PlaySound sound = new PlaySound();
       sound.play(sound.load("/music/startup.wav"));
    }
}
